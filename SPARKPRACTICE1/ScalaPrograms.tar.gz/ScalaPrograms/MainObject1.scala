object MainObject1{
  def main(args: Array[String]){
    for(a <- 7 to 31 if a%2==1){
     println(a);
       }
    }
}
