import scala.io.StdIn.{readLine, readInt}
import scala.math._
import scala.collection.mutable.ArrayBuffer
import java.io.PrintWriter
import scala.io.Source

object ScalaTutorial9 {
 def main (args:Array[String]){

	val name = "ajay"
	val age = 26
	val weight = 73.5
	println(s"Hello $name")
	println(f"I am ${age -2} and weight $weight%.2f")  

	printf("'%5d'\n",5)
	printf("'%-5d'\n",5)  
   }
}
