import scala.io.StdIn.{readLine, readInt}
import scala.math._
import scala.collection.mutable.ArrayBuffer
import java.io.PrintWriter
import scala.io.Source

object ScalaTutorial12 {
 def main (args:Array[String]){

	def sayHi() : Unit = {
	  println("HI HOW ARE YOU")
}
sayHi

  }
}
