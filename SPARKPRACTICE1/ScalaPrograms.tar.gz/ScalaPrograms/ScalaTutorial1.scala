object ScalaTutorial1 {
 def main(args: Array[String]){
  var i = 0
  
  do {
     println(i)
	i += 2
	} while (i <= 20)
     }
}
