object MainObject{
  def main (args: Array[String]){
   var a = 0;
   while(true){
      println(a);
       a = a+1
	}
     }
}
