object ScalaTutorial3 {
  def main(args:Array[String]){
   var i = 0
    val randLetters = "abcdef"
    for (i <- 0 until randLetters.length)
      println(randLetters(i))
	}
}
