object ScalaTutorial {
 def main (args: Array[String]){
  var i = 0
  
  while(i <= 10){
    println(i)
      i += 1
    }
  }
}
