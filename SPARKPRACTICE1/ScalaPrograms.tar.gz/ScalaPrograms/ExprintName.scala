/* Scala program to print your name*/
 object ExprintName {
   def main(args: Array[String]){
       println("My name is Ajay!")
	}
}
