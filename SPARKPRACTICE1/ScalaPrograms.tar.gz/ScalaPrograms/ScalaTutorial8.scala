import scala.io.StdIn.{readLine, readInt}
import scala.math._
import scala.collection.mutable.ArrayBuffer
import java.io.PrintWriter
import scala.io.Source

object ScalaTutorial8 {
 def main (args:Array[String]){
    var numberGuss = 0 

      do {
	print("Guess a Number ")
		numberGuss = readLine.toInt
	}while(numberGuss != 10)
	printf("you gussed the screat number %d\n",10)
		}
	}
