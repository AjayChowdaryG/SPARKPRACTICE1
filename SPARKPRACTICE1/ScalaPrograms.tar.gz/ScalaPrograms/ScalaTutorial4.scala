object ScalaTutorial4 {
   def main(args: Array[String]){
   var i = 0
   val aList = List(1,2,3,4,5,6,7,8)
   for (i <- aList){
      println("List items " +i)
	}
    }
}
