object ScalaTutorial2 {
 def main(args: Array[String]){
  var i = 0

   for (i <- 1 to 20)
     println(i)
    }
}
