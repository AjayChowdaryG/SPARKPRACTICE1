object ExfindLarge {
  def main(args: Array[String]){
    var num1 = 20;
    var num2 = 30;
    var x = 10;
    if (num1>num2){
        println("Largest number is: " + num1);
	}
	 else{
		println("Largest number is: " + num2); 
		}
	}
}
