import scala.io.StdIn.{readLine, readInt}
import scala.math._
import scala.collection.mutable.ArrayBuffer
import java.io.PrintWriter
import scala.io.Source

object ScalaTutorial11 {
 def main (args:Array[String]){
   
  def getSum(num1 : Int = 1, num2 : Int = 1): Int = return {num1 +num2
}
println("25 + 20 = " + getSum(25,20))
	
  }
}
